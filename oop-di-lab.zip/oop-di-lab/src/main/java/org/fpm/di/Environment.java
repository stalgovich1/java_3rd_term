package org.fpm.di;

public interface Environment {
    Container configure(Configuration configuration);
}
