package org.fpm.di.example;

public class B extends A {
}
