package org.fpm.di.example;

public class A {
}
