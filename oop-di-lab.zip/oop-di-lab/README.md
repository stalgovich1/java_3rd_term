# oop-di-lab

Generated with:

- Gradle 7.5
- JVM 18.0.2